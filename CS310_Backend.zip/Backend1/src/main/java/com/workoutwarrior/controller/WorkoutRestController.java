package com.workoutwarrior.controller;

import org.springframework.data.domain.Sort;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.CriteriaDefinition;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.workoutwarrior.model.User;
import com.workoutwarrior.model.Workout;
import com.workoutwarrior.payload.ExerciseNote;
import com.workoutwarrior.payload.WorkoutPayload;
import com.workoutwarrior.repo.UserRepo;
import com.workoutwarrior.repo.WorkoutRepository;

import ch.qos.logback.classic.Logger;
import jakarta.annotation.PostConstruct;

@RestController
@RequestMapping("/workout")
public class WorkoutRestController {

	@Autowired private WorkoutRepository workoutRepository;
	@Autowired private UserRepo userRepository;
	@Autowired private MongoTemplate mongoTemplate;
	
	private static final Logger logger = (Logger) LoggerFactory.getLogger(WorkoutRestController.class);

	
	@GetMapping("/getallworkouts/{id}")
	public List<Workout> getAllWorkout(@PathVariable("id") String id)
	{
		Optional<User> user = userRepository.findById(id);
		List<Workout> workout = workoutRepository.findByUser(user);
		return workout;	
	}
	
	@PostMapping("/createworkout")
	public Workout createWorkout(@RequestBody WorkoutPayload workoutpayload)
	{
		User user = new User();
		user.setUserId(workoutpayload.getUserid());
		
		Workout workout = new Workout(user, workoutpayload.getExercise(), LocalDateTime.now());
		workoutRepository.save(workout);
		
		return workout;
	}

	@DeleteMapping("/delete/{id}")
	public String deleteWorkout(@PathVariable("id") String id)
	{
		workoutRepository.deleteById(id.strip());
		return "Workout \'" + id.strip() + "\' is removed!";
	}
	
}
